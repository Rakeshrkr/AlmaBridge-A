
almaApp.controller('contactController', function($scope) {
$scope.message = 'Contact us! JK. This is just a demo.';
});
