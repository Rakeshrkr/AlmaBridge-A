almaApp.controller('loginController', function($scope) {
$scope.message = 'Look! I am a login page.';
});