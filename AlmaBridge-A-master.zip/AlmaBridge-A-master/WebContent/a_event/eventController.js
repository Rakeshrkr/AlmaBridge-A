almaApp.controller('eventController', function($scope) {
$scope.message = 'Look! I am an Event page.';
});