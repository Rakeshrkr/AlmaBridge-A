almaApp.controller('jobController', function($scope) {
$scope.message = 'Look! I am an job page.';
});