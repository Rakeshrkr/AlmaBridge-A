
almaApp.service('userService',['$http','$q','$rootScope',function($http,$q,$rootScope){
	var BASE_URL = 'http://localhost:9400/AlmaBridgeB' 
	var self = this ;
	self.user = {errorCode:"",errorMsg:"",userId:"",name:"",password:"",email:"",address:"",mobile:"",roleId:"",reason:"",isOnline:"",status:""};
	self.users = [] ;
	
	self.getAllUsers = getAllUsers();
	
	function getAllUsers(){
		console.log("In the method of getAllUsers of user service")
		
		return $http.get(BASE_URL+'/users')
		      	.then(
		      	function(response){
		      		console.log("getting response")
		      		return response.data ;
		      	}		
		      	);
	}
}]);