almaApp.controller('friendController', function($scope) {
$scope.message = 'Look! I am a friend page.';
});