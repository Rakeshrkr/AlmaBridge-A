almaApp.controller('registerController', function($scope) {
$scope.message = 'Look! I am a register page.';
});