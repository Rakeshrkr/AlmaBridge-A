package edu.almabridge.daoImpl;

import edu.almabridge.dao.Blog_CommentDAO;

public class Blog_CommentDAOImpl  {

}
